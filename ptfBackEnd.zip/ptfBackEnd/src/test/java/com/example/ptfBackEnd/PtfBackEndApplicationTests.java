package com.example.ptfBackEnd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PtfBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
